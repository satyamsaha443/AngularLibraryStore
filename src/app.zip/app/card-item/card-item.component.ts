import { Component, EventEmitter, Input, Output } from '@angular/core';

interface Book {
  ISBN: number,
  title: string,
  author: string,
  summary: string,
  image: string,
  price: {
    currency: string,
    value: number,
    displayValue: string
  }
}

@Component({
  selector: 'app-card-item',
  templateUrl: './card-item.component.html',
  styleUrls: ['./card-item.component.css']
})
export class CardItemComponent {
  @Input() item: Book | undefined;
  @Output() removeFromCart: EventEmitter<number> = new EventEmitter();
  removeBook(ISBN: number){
    this.removeFromCart.emit(ISBN);
  }
}
